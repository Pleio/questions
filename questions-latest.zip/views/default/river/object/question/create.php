<?php
/**
 * River entry for new questions
 *
 * @package Questions
 */

echo elgg_view('river/elements/layout', array(
		'item' => $vars['item']
));
